# LDOS 5.3.0 Model III DND#1 + TTY300 boot floppy

File: LDOS53_DND1PLAY_TTY300_ModelIII.hfe
Format: HxC HFE v1, 40 tracks, single-sided, double density, Model III LDOS 5.3.0.

Contents
- DND1PLAY/BAS — the self-contained 449-line BASIC dungeon game
- TTY300/BAS    — the 42-line 300 baud RS-232 printing terminal
- BASIC/CMD, BASIC/OV1..OV4 and all LDOS system files are retained.

To run on the TRS-80 Model III (Gotek/FlashFloppy or trs80gp):
  1. Boot from the new HFE disk.
  2. Respond to the LDOS date and time prompts.
  3. At "LDOS Ready", enter BASIC.
  4. From the LBASIC Ready prompt, enter:
        LOAD "DND1PLAY/BAS"
        RUN
     Or for the serial terminal:
        LOAD "TTY300/BAS"
        RUN
  5. The TTY300 program uses UART ports 232..235. Don't load an
     LDOS serial driver on the same port simultaneously.
     Use a real RS-232 level null-modem adapter at 300 baud 8N1.

Changes relative to uploaded ldos53_dsk.hfe:
- Entered/saved both BASIC programs on a working copy using trs80gp.
- Removed DOS/HLP and BASIC/HLP from that working copy, which are
  optional help/reference files (not needed to boot or run LBASIC).
- These two deletions free 20 x 1.5KiB granules = 30KiB of raw disk
  allocation. All other files and data remain unchanged.
- Confirmed both BASIC file streams can be parsed to normal END
  markers with the full 449 and 42 source line numbers respectively.
- Decoded and checked all 720 physical sectors and verified updated
  CRCs for modified directory sectors.
- The LDOS boot sector is identical to the source boot sector.
- The final modified image has NOT yet been separately boot-tested on
  physical hardware; the original supplied HFE booted in earlier
  trs80gp tests. Start by confirming DIR :0 and both LOAD commands.

Source project: https://github.com/royedmund/dnd-1
